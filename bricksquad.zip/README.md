#BrickSquad
###EP-projektet för oss som gillar Lego mer än stegu!

Gruppens medlemmar är:
* Daniel Rönnkvist
* Erik Larsson
* Erik Olsson
* Pelle Sernander


Använd denna kodsnippet i toppen av varje fil!

	<?php
		/**
		 * 		Grupp 18 - 2012-11-27
		 * 	Name:	Erik Larsson
		 *	file: 	sqlconfig.php
		 *	Desc:	open connection to our Database.
		 */
	?>

### Alla kommentarer skall skrivas på engelska (snälla?)