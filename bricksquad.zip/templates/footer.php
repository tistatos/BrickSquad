<?php
	/**
	 *    Grupp 18 - 2012-12-25
	 *  Name: Erik Larsson
	 *  file:   footer.php
	 *  Desc: footer of pages with links for HTML5 and CSS validation
	 */
?>
		<div class="footnote">
			<p> Bricksquad - a EP-project for media technology & Engineering 2012/2013 by Daniel R&ouml;nnkvist, Erik Larsson, Erik Olsson, Pelle Serander</p>
			<p> <a href="http://validator.w3.org/check/referer"> Validate HTML5 </a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">Validate CSS </a></p>
		</div>
	</body>
</html>